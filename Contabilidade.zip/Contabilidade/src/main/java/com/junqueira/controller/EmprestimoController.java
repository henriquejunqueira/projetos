package com.junqueira.controller;

import com.junqueira.dao.Conexao;
import com.junqueira.dao.EmprestimoDao;
import com.junqueira.model.Conta;
import com.junqueira.model.Emprestimo;
import com.junqueira.model.Usuario;
import com.junqueira.util.Alerta;
import com.junqueira.util.ValidaCampos;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import org.hibernate.Session;

public class EmprestimoController implements Initializable, ICadastro {

    @FXML
    private Button btnSalvar;
    @FXML
    private Button btnExcluir;
    @FXML
    private Button btnSair;
    @FXML
    private TextField tfId;
    @FXML
    private TextField tfValor;
    @FXML
    private ComboBox<Usuario> cbUsuario;
    @FXML
    private TextField tfCliente;
    @FXML
    private TextField tfPesquisa;
    @FXML
    private TextField tfDataEmprestimo;
    @FXML
    private TableView<Emprestimo> tabelaEmprestimo;
    @FXML
    private Button btnNovo;
    @FXML
    private Button btnImprimir;

    Long id;
    private EmprestimoDao dao = new EmprestimoDao();
    private ObservableList<Emprestimo> olEmprestimo = FXCollections.observableArrayList();
    private ObservableList<Usuario> olUsuario = FXCollections.observableArrayList();
    private List<Emprestimo> listaEmprestimos;
    private Emprestimo emprestimoSelecionado = new Emprestimo();
    private Alerta alerta = new Alerta();
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        criarColunasTabela();
        atualizarTabela();
        adicionarTooltip();
        popularComboBoxUsuario();
    }    

    @FXML
    private void salvarCadastro(ActionEvent event) throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
        
        Emprestimo emprestimo = new Emprestimo();
        if(ValidaCampos.checarCampoVazio(cbUsuario, tfCliente, tfValor, tfDataEmprestimo)){
            if(emprestimoSelecionado.getId() != null){
                emprestimo.setId(emprestimoSelecionado.getId());
            }
            emprestimo.setUsuario(cbUsuario.getSelectionModel().getSelectedItem());
            emprestimo.setCliente(tfCliente.getText());
            emprestimo.setValor(Double.parseDouble(tfValor.getText()));
            emprestimo.setData_emprestimo(tfDataEmprestimo.getText());
            
            dao.salvar(emprestimo);

            limparCamposFormulario();
            atualizarTabela();
        }
        
    }

    @FXML
    private void excluirCadastro(ActionEvent event) {
        
        if(alerta.msgConfirmaExclusao(tfCliente.getText())){
            dao.excluir(emprestimoSelecionado);

            limparCamposFormulario();
            atualizarTabela();
        }
        
    }

    @FXML
    private void novoCadastro(ActionEvent event) {
        limparCamposFormulario();
    }

    @FXML
    private void sairCadastro(ActionEvent event) {
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void clicarTabela(MouseEvent event) {
        setCamposFormulario();
    }

    @FXML
    private void pesquisarRegistro(KeyEvent event) {
        atualizarTabela();
    }

    @Override
    public void criarColunasTabela() {
        TableColumn<Emprestimo, Long> colunaId = new TableColumn<>("ID");
        TableColumn<Emprestimo, Usuario> colunaUsuario = new TableColumn<>("USUÁRIO");
        TableColumn<Emprestimo, String> colunaCliente = new TableColumn<>("EMPRÉSTIMO");
        TableColumn<Emprestimo, Double> colunaValor = new TableColumn<>("VALOR");
        TableColumn<Emprestimo, String> colunaDataEmprestimo = new TableColumn<>("DATA EMPRÉSTIMO");
        
        tabelaEmprestimo.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);
        
        tabelaEmprestimo.getColumns().addAll(colunaId, colunaUsuario, colunaCliente, colunaValor, colunaDataEmprestimo);
        
        colunaId.setCellValueFactory(new PropertyValueFactory("id"));
        colunaUsuario.setCellValueFactory(new PropertyValueFactory("usuario"));
        colunaCliente.setCellValueFactory(new PropertyValueFactory("cliente"));
        colunaValor.setCellValueFactory(new PropertyValueFactory("valor"));
        colunaDataEmprestimo.setCellValueFactory(new PropertyValueFactory("data_emprestimo"));
    }

    @Override
    public void atualizarTabela() {
        olEmprestimo.clear();
        listaEmprestimos = dao.consultar(tfPesquisa.getText());
        
        for(Emprestimo e : listaEmprestimos){
            olEmprestimo.add(e);
        }
        
        tabelaEmprestimo.getItems().setAll(olEmprestimo);
        tabelaEmprestimo.getSelectionModel().selectFirst();
    }

    @Override
    public void setCamposFormulario() {
        emprestimoSelecionado = tabelaEmprestimo.getItems().get(tabelaEmprestimo.getSelectionModel().getSelectedIndex());
        cbUsuario.setValue(emprestimoSelecionado.getUsuario());
        tfCliente.setText(emprestimoSelecionado.getCliente());
        tfValor.setText(emprestimoSelecionado.getValor().toString());
        tfDataEmprestimo.setText(emprestimoSelecionado.getData_emprestimo());
    }

    @Override
    public void limparCamposFormulario() {
        emprestimoSelecionado.setId(null);
        tfCliente.clear();
        tfValor.clear();
        tfDataEmprestimo.clear();
    }

    @Override
    public void adicionarTooltip() {
        Tooltip ttUsu = new Tooltip("Nome do usuario. Campo obrigatório!");
        ttUsu.setFont(new Font("Arial", 14));
        cbUsuario.setTooltip(ttUsu);
        
        Tooltip ttCliente = new Tooltip("Pessoa para quem o usuario fez o empréstimo. Campo obrigatório!");
        ttCliente.setFont(new Font("Arial", 14));
        tfCliente.setTooltip(ttCliente);
        
        Tooltip ttValor = new Tooltip("Valor que o usuário emprestou. Campo obrigatório!");
        ttValor.setFont(new Font("Arial", 14));
        tfValor.setTooltip(ttValor);
        
        Tooltip ttDataEmprestimo = new Tooltip("Data que o usuario fez o empréstimo. Campo obrigatório!");
        ttDataEmprestimo.setFont(new Font("Arial", 14));
        tfDataEmprestimo.setTooltip(ttDataEmprestimo);
    }
    
    private void popularComboBoxUsuario(){
        List<Usuario> list = new ArrayList<>();
        Session session = Conexao.getSessionFactory().openSession();
        session.beginTransaction();
        list = session.createQuery(" from Usuario").getResultList();
        session.getTransaction().commit();
        session.close();
        
        for(Usuario usuario : list){
            olUsuario.add(usuario);
        }
        cbUsuario.setItems(olUsuario);
    }

    @FXML
    private void imprimir(ActionEvent event) {
    }
    
}
