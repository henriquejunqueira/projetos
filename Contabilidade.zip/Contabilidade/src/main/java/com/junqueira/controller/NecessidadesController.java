package com.junqueira.controller;

import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import com.junqueira.dao.Conexao;
import com.junqueira.dao.ContaDao;
import com.junqueira.dao.NecessidadeDao;
import com.junqueira.model.Conta;
import com.junqueira.model.Necessidade;
import com.junqueira.model.Usuario;
import com.junqueira.util.Alerta;
import com.junqueira.util.ValidaCampos;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import org.hibernate.Session;

public class NecessidadesController implements Initializable, ICadastro {

    @FXML
    private Button btnSalvar;
    @FXML
    private Button btnExcluir;
    @FXML
    private Button btnSair;
    @FXML
    private TextField tfId;
    @FXML
    private TextField tfValorCompra;
    @FXML
    private ComboBox<Usuario> cbUsuario;
    @FXML
    private TextField tfLocalCompra;
    @FXML
    private TextField tfPesquisa;
    @FXML
    private TableView<Necessidade> tabelaNecessidade;
    @FXML
    private TextField tfDataCompra;

    Long id;
    private NecessidadeDao dao = new NecessidadeDao();
    private ObservableList<Necessidade> olNecessidade = FXCollections.observableArrayList();
    private ObservableList<Usuario> olUsuario = FXCollections.observableArrayList();
    private List<Necessidade> listaNecessidades;
    private Necessidade necessidadeSelecionada = new Necessidade();
    private Alerta alerta = new Alerta();
    @FXML
    private Button btnNovo;
    @FXML
    private Button btnImprimir;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        criarColunasTabela();
        atualizarTabela();
        adicionarTooltip();
        popularComboBoxUsuario();
    }    

    @FXML
    private void salvarCadastro(ActionEvent event) throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
        Necessidade necessidade = new Necessidade();
        if(ValidaCampos.checarCampoVazio(tfValorCompra, tfLocalCompra, tfDataCompra)){
            if(necessidadeSelecionada.getId() != null){
                necessidade.setId(necessidadeSelecionada.getId());
            }
            necessidade.setUsuario(cbUsuario.getSelectionModel().getSelectedItem());
            necessidade.setValor_compra(Double.parseDouble(tfValorCompra.getText()));
            necessidade.setLocal_compra(tfLocalCompra.getText());
            necessidade.setData_compra(tfDataCompra.getText());
            
            dao.salvar(necessidade);

            limparCamposFormulario();
            atualizarTabela();
        }
    }

    @FXML
    private void excluirCadastro(ActionEvent event) {
        if(alerta.msgConfirmaExclusao(tfDataCompra.getText())){
            dao.excluir(necessidadeSelecionada);

            limparCamposFormulario();
            atualizarTabela();
        }
    }

    @FXML
    private void novoCadastro(ActionEvent event) {
        limparCamposFormulario();
    }

    @FXML
    private void fecharJanela(ActionEvent event) {
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void clicarTabela(MouseEvent event) {
        setCamposFormulario();
    }

    @FXML
    private void pesquisarRegistro(KeyEvent event) {
        atualizarTabela();
    }

    @Override
    public void criarColunasTabela() {
        TableColumn<Necessidade, Long> colunaId = new TableColumn<>("ID");
        TableColumn<Necessidade, Usuario> colunaUsuario = new TableColumn<>("USUÁRIO");
        TableColumn<Necessidade, Double> colunaValorCompra = new TableColumn<>("VALOR");
        TableColumn<Necessidade, Double> colunaLocalCompra = new TableColumn<>("LOCAL COMPRA");
        TableColumn<Necessidade, Double> colunaDataCompra = new TableColumn<>("DATA COMPRA");
        
        tabelaNecessidade.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);
        
        tabelaNecessidade.getColumns().addAll(colunaId, colunaUsuario, colunaValorCompra, colunaLocalCompra, colunaDataCompra);
        
        colunaId.setCellValueFactory(new PropertyValueFactory("id"));
        colunaUsuario.setCellValueFactory(new PropertyValueFactory("usuario"));
        colunaValorCompra.setCellValueFactory(new PropertyValueFactory("valor_compra"));
        colunaLocalCompra.setCellValueFactory(new PropertyValueFactory("local_compra"));
        colunaDataCompra.setCellValueFactory(new PropertyValueFactory("data_compra"));
    }

    @Override
    public void atualizarTabela() {
        olNecessidade.clear();
        listaNecessidades = dao.consultar(tfPesquisa.getText());
        
        for(Necessidade n : listaNecessidades){
            olNecessidade.add(n);
        }
        
        tabelaNecessidade.getItems().setAll(olNecessidade);
        tabelaNecessidade.getSelectionModel().selectFirst();
    }

    @Override
    public void setCamposFormulario() {
        necessidadeSelecionada = tabelaNecessidade.getItems().get(tabelaNecessidade.getSelectionModel().getSelectedIndex());
        cbUsuario.setValue(necessidadeSelecionada.getUsuario());
        tfValorCompra.setText(necessidadeSelecionada.getValor_compra().toString());
        tfLocalCompra.setText(necessidadeSelecionada.getLocal_compra());
        tfDataCompra.setText(necessidadeSelecionada.getData_compra());
    }

    @Override
    public void limparCamposFormulario() {
        necessidadeSelecionada.setId(null);
        tfValorCompra.clear();
        tfLocalCompra.clear();
        tfDataCompra.clear();
    }

    @Override
    public void adicionarTooltip() {
        Tooltip ttUsu = new Tooltip("Nome do usuario. Campo obrigatório!");
        ttUsu.setFont(new Font("Arial", 14));
        cbUsuario.setTooltip(ttUsu);
        
        Tooltip ttValor = new Tooltip("Valor da conta do usuario. Campo obrigatório!");
        ttValor.setFont(new Font("Arial", 14));
        tfValorCompra.setTooltip(ttValor);
        
        Tooltip ttLocal = new Tooltip("Local da compra do usuario. Campo obrigatório!");
        ttLocal.setFont(new Font("Arial", 14));
        tfLocalCompra.setTooltip(ttLocal);
        
        Tooltip ttDataCompra = new Tooltip("Data que o usuario fez a compra. Campo obrigatório!");
        ttDataCompra.setFont(new Font("Arial", 14));
        tfDataCompra.setTooltip(ttDataCompra);
    }
    
    private void popularComboBoxUsuario(){
        List<Usuario> list = new ArrayList<>();
        Session session = Conexao.getSessionFactory().openSession();
        session.beginTransaction();
        list = session.createQuery(" from Usuario").getResultList();
        session.getTransaction().commit();
        session.close();
        
        for(Usuario usuario : list){
            olUsuario.add(usuario);
        }
        cbUsuario.setItems(olUsuario);
    }

    @FXML
    private void imprimir(ActionEvent event) {
    }
}
