package com.junqueira.controller;

import com.junqueira.dao.Conexao;
import com.junqueira.dao.ContaDao;
import com.junqueira.model.Conta;
import com.junqueira.model.Usuario;
import com.junqueira.util.Alerta;
import com.junqueira.util.ValidaCampos;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import org.hibernate.Session;

public class ContaController implements Initializable, ICadastro {

    @FXML
    private Button btnSalvar;
    @FXML
    private Button btnExcluir;
    @FXML
    private Button btnSair;
    @FXML
    private ComboBox<Usuario> cbUsuario;
    @FXML
    private TextField tfAluguel;
    @FXML
    private TextField tfAgua;
    @FXML
    private TextField tfLuz;
    @FXML
    private TextField tfNetflix;
    @FXML
    private TextField tfInternet;
    @FXML
    private TextField tfPesquisa;
    @FXML
    private TextField tfDataCadastro;
    @FXML
    private TableView<Conta> tabelaConta;
    @FXML
    private Button btnNovo;
    @FXML
    private Button btnImprimir;
    @FXML
    private Label lblTotalContas;
    @FXML
    private Label lblDivisaoPorTres;
    @FXML
    private Label lblDivisaoNetflix;
    
    Long id;
    private ContaDao dao = new ContaDao();
    private ObservableList<Conta> olConta = FXCollections.observableArrayList();
    private ObservableList<Usuario> olUsuario = FXCollections.observableArrayList();
    private List<Conta> listaContas;
    private Conta contaSelecionada = new Conta();
    private Alerta alerta = new Alerta();
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        criarColunasTabela();
        atualizarTabela();
        adicionarTooltip();
        popularComboBoxUsuario();
    }    

    @FXML
    private void salvarCadastro(ActionEvent event) throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
        Conta conta = new Conta();
        double totalConta;
        double divisaoConta;
        double divisaoNetflix;
        
        if(ValidaCampos.checarCampoVazio(cbUsuario, tfAluguel, tfAgua, tfLuz, tfNetflix, tfInternet, tfDataCadastro)){
            if(contaSelecionada.getId() != null){
                conta.setId(contaSelecionada.getId());
            }
            
            conta.setUsuario(cbUsuario.getSelectionModel().getSelectedItem());
            conta.setAluguel(Double.parseDouble(tfAluguel.getText()));
            conta.setAgua(Double.parseDouble(tfAgua.getText()));
            conta.setLuz(Double.parseDouble(tfLuz.getText()));
            conta.setNetflix(Double.parseDouble(tfNetflix.getText()));
            conta.setInternet(Double.parseDouble(tfInternet.getText()));
            conta.setData(tfDataCadastro.getText());
            
            double aluguel = Double.parseDouble(tfAluguel.getText());
            double agua = Double.parseDouble(tfAgua.getText());
            double luz = Double.parseDouble(tfLuz.getText());
            double netflix = Double.parseDouble(tfNetflix.getText());
            double internet = Double.parseDouble(tfInternet.getText());
            
            totalConta = (aluguel + agua + luz + netflix + internet);
            divisaoConta = ((totalConta - netflix) / 3);
            divisaoNetflix = (netflix / 4);
            
            conta.setTotal_Conta(totalConta);
            conta.setDivisao_Conta(divisaoConta);
            conta.setDivisao_netflix(divisaoNetflix);
            
            dao.salvar(conta);
            limparCamposFormulario();
            atualizarTabela();
        }
    }

    @FXML
    private void excluirCadastro(ActionEvent event) {
        if(alerta.msgConfirmaExclusao(tfDataCadastro.getText())){
            dao.excluir(contaSelecionada);

            limparCamposFormulario();
            atualizarTabela();
        }
    }

    @FXML
    private void novoCadastro(ActionEvent event) {
        limparCamposFormulario();
    }

    @FXML
    private void fecharJanela(ActionEvent event) {
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void clicarTabela(MouseEvent event) {
        setCamposFormulario();
    }

    @FXML
    private void pesquisarRegistro(KeyEvent event) {
        atualizarTabela();
    }

    @Override
    public void criarColunasTabela() {
        TableColumn<Conta, Long> colunaId = new TableColumn<>("ID");
        TableColumn<Conta, Usuario> colunaUsuario = new TableColumn<>("USUÁRIO");
        TableColumn<Conta, Double> colunaAluguel = new TableColumn<>("ALUGUEL");
        TableColumn<Conta, Double> colunaAgua = new TableColumn<>("ÁGUA");
        TableColumn<Conta, Double> colunaLuz = new TableColumn<>("LUZ");
        TableColumn<Conta, Double> colunaNetflix = new TableColumn<>("NETFLIX");
        TableColumn<Conta, Double> colunaInternet = new TableColumn<>("INTERNET");
        TableColumn<Conta, String> colunaDataAtual = new TableColumn<>("DATA ATUAL");
        TableColumn<Conta, Double> colunaTotalConta = new TableColumn<>("TOTAL CONTA");
        TableColumn<Conta, Double> colunaDivisaoConta = new TableColumn<>("DIVISÃO CONTA");
        
        tabelaConta.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);
        
        tabelaConta.getColumns().addAll(colunaId, colunaUsuario, colunaAluguel, colunaAgua, colunaLuz, colunaNetflix, colunaInternet, colunaDataAtual, colunaTotalConta, colunaDivisaoConta);
        
        colunaId.setCellValueFactory(new PropertyValueFactory("id"));
        colunaUsuario.setCellValueFactory(new PropertyValueFactory("usuario"));
        colunaAluguel.setCellValueFactory(new PropertyValueFactory("aluguel"));
        colunaAgua.setCellValueFactory(new PropertyValueFactory("agua"));
        colunaLuz.setCellValueFactory(new PropertyValueFactory("luz"));
        colunaNetflix.setCellValueFactory(new PropertyValueFactory("netflix"));
        colunaInternet.setCellValueFactory(new PropertyValueFactory("internet"));
        colunaDataAtual.setCellValueFactory(new PropertyValueFactory("data"));
        colunaTotalConta.setCellValueFactory(new PropertyValueFactory("total_conta"));
        colunaDivisaoConta.setCellValueFactory(new PropertyValueFactory("divisao_conta"));
        
    }

    @Override
    public void atualizarTabela() {
        olConta.clear();
        listaContas = dao.consultar(tfPesquisa.getText());
        
        for(Conta c : listaContas){
            olConta.add(c);
        }
        
        tabelaConta.getItems().setAll(olConta);
        tabelaConta.getSelectionModel().selectFirst();
    }

    @Override
    public void setCamposFormulario() {
        contaSelecionada = tabelaConta.getItems().get(tabelaConta.getSelectionModel().getSelectedIndex());
        cbUsuario.setValue(contaSelecionada.getUsuario());
        tfAluguel.setText(contaSelecionada.getAluguel().toString());
        tfAgua.setText(contaSelecionada.getAgua().toString());
        tfLuz.setText(contaSelecionada.getLuz().toString());
        tfNetflix.setText(contaSelecionada.getNetflix().toString());
        tfInternet.setText(contaSelecionada.getInternet().toString());
        tfDataCadastro.setText(contaSelecionada.getData());
        lblTotalContas.setText(contaSelecionada.getTotal_Conta().toString());
        lblDivisaoPorTres.setText(contaSelecionada.getDivisao_Conta().toString());
        lblDivisaoNetflix.setText(contaSelecionada.getDivisao_netflix().toString());
        
        
    }

    @Override
    public void limparCamposFormulario() {
        contaSelecionada.setId(null);
        tfAluguel.clear();
        tfAgua.clear();
        tfLuz.clear();
        tfNetflix.clear();
        tfInternet.clear();
        tfDataCadastro.clear();
        lblTotalContas.setText("00,00");
        lblDivisaoPorTres.setText("00,00");
    }

    @Override
    public void adicionarTooltip() {
        Tooltip ttUsu = new Tooltip("Nome do usuario. Campo obrigatório!");
        ttUsu.setFont(new Font("Arial", 14));
        cbUsuario.setTooltip(ttUsu);
        
        Tooltip ttAluguel = new Tooltip("Conta de aluguel do usuario. Campo obrigatório!");
        ttAluguel.setFont(new Font("Arial", 14));
        tfAluguel.setTooltip(ttAluguel);
        
        Tooltip ttAgua = new Tooltip("Conta de água do usuario. Campo obrigatório!");
        ttAgua.setFont(new Font("Arial", 14));
        tfAgua.setTooltip(ttAgua);
        
        Tooltip ttLuz = new Tooltip("Conta de luz do usuario. Campo obrigatório!");
        ttLuz.setFont(new Font("Arial", 14));
        tfLuz.setTooltip(ttLuz);
        
        Tooltip ttNetflix = new Tooltip("Conta da Netflix do usuario. Campo obrigatório!");
        ttNetflix.setFont(new Font("Arial", 14));
        tfNetflix.setTooltip(ttNetflix);
        
        Tooltip ttInternet = new Tooltip("Conta de internet do usuario. Campo obrigatório!");
        ttInternet.setFont(new Font("Arial", 14));
        tfInternet.setTooltip(ttInternet);
        
        Tooltip ttNascimento = new Tooltip("Data que o usuario cadastrou a conta. Campo obrigatório!");
        ttNascimento.setFont(new Font("Arial", 14));
        tfDataCadastro.setTooltip(ttNascimento);
        
        Tooltip ttTotalContas = new Tooltip("Total da conta cadastrada");
        ttTotalContas.setFont(new Font("Arial", 14));
        lblTotalContas.setTooltip(ttTotalContas);
        
        Tooltip ttDivisaoContas = new Tooltip("Divisão da conta cadastrada por 3");
        ttDivisaoContas.setFont(new Font("Arial", 14));
        lblDivisaoPorTres.setTooltip(ttDivisaoContas);
        
        Tooltip ttDivisaoNetflix = new Tooltip("Divisão da conta da Netflix por 4 (Henrique, Matheus, Alexandre e Gabi)");
        ttDivisaoNetflix.setFont(new Font("Arial", 14));
        lblDivisaoNetflix.setTooltip(ttDivisaoNetflix);
    }
    
    private void popularComboBoxUsuario(){
        List<Usuario> list = new ArrayList<>();
        Session session = Conexao.getSessionFactory().openSession();
        session.beginTransaction();
        list = session.createQuery(" from Usuario").getResultList();
        session.getTransaction().commit();
        session.close();
        
        for(Usuario usuario : list){
            olUsuario.add(usuario);
        }
        cbUsuario.setItems(olUsuario);
    }

    @FXML
    private void imprimir(ActionEvent event) {
        
    }
    
}
