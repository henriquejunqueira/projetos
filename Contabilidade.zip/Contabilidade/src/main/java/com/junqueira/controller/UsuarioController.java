package com.junqueira.controller;

import com.junqueira.dao.UsuarioDao;
import com.junqueira.model.Usuario;
import com.junqueira.util.Alerta;
import com.junqueira.util.ValidaCampos;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.control.Tooltip;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class UsuarioController implements Initializable, ICadastro {

    @FXML
    private Button btnSair;
    @FXML
    private TableView<Usuario> tabelaUsuario;
    @FXML
    private TextField tfUsuario;
    @FXML
    private TextField tfSalario;
    @FXML
    private TextField tfNascimento;
    @FXML
    private TextField tfPesquisa;
    @FXML
    private Button btnSalvar;
    @FXML
    private Button btnExcluir;
    @FXML
    private Button BtnNovo;
    @FXML
    private TextField tfId;

    Long id;
    private UsuarioDao dao = new UsuarioDao();
    private ObservableList<Usuario> olUsuario = FXCollections.observableArrayList();
    private List<Usuario> listaUsuarios;
    private Usuario usuarioSelecionado = new Usuario();
    private Alerta alerta = new Alerta();
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        criarColunasTabela();
        atualizarTabela();
        adicionarTooltip();
    }    

    @FXML
    private void salvarCadastro(ActionEvent event) throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
        Usuario usuario = new Usuario();
        if(ValidaCampos.checarCampoVazio(tfUsuario, tfSalario, tfNascimento)){
            if(usuarioSelecionado.getId() != null){
                usuario.setId(usuarioSelecionado.getId());
            }
            usuario.setUsuario(tfUsuario.getText());
            usuario.setSalario(Double.parseDouble(tfSalario.getText()));
            usuario.setNascimento(tfNascimento.getText());
            
            dao.salvar(usuario);

            limparCamposFormulario();
            atualizarTabela();
        }
        
    }

    @FXML
    private void excluirCadastro(ActionEvent event) {
        if(alerta.msgConfirmaExclusao(tfUsuario.getText())){
            dao.excluir(usuarioSelecionado);

            limparCamposFormulario();
            atualizarTabela();
        }
    }

    @FXML
    private void novoCadastro(ActionEvent event) {
        limparCamposFormulario();
    }

    @FXML
    private void fecharJanela(ActionEvent event) {
        Stage stage = (Stage) btnSair.getScene().getWindow();
        stage.close();
    }

    @Override
    public void criarColunasTabela() {
        TableColumn<Usuario, Long> colunaId = new TableColumn<>("ID");
        TableColumn<Usuario, String> colunaUsuario = new TableColumn<>("USUÁRIO");
        TableColumn<Usuario, Double> colunaSalario = new TableColumn<>("SALÁRIO");
        TableColumn<Usuario, String> colunaNascimento = new TableColumn<>("NASCIMENTO");
        
        tabelaUsuario.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);
        tabelaUsuario.getColumns().addAll(colunaId, colunaUsuario, colunaSalario, colunaNascimento);
        
        colunaId.setCellValueFactory(new PropertyValueFactory("id"));
        colunaUsuario.setCellValueFactory(new PropertyValueFactory("usuario"));
        colunaSalario.setCellValueFactory(new PropertyValueFactory("salario"));
        colunaNascimento.setCellValueFactory(new PropertyValueFactory("nascimento"));

    }

    @Override
    public void atualizarTabela() {
        // limpa a lista
        olUsuario.clear();
        
        // puxa as informações do bd
        listaUsuarios = dao.consultar(tfPesquisa.getText());
        
        // coloca os dados do bd na lista
        for(Usuario u : listaUsuarios){
            
            olUsuario.add(u);
            
        }
        
        tabelaUsuario.getItems().setAll(olUsuario);
        
        // localiza o primeiro item da lista
        tabelaUsuario.getSelectionModel().selectFirst();
    }

    @Override
    public void setCamposFormulario() {
        usuarioSelecionado = tabelaUsuario.getItems().get(tabelaUsuario.getSelectionModel().getSelectedIndex());
        tfUsuario.setText(usuarioSelecionado.getUsuario());
        tfSalario.setText(usuarioSelecionado.getSalario().toString());
        tfNascimento.setText(usuarioSelecionado.getNascimento());
        
    }

    @Override
    public void limparCamposFormulario() {
        usuarioSelecionado.setId(null);
        tfUsuario.clear();
        tfSalario.clear();
        tfNascimento.clear();
    }

    @Override
    public void adicionarTooltip() {
        Tooltip ttUsu = new Tooltip("Nome do usuario. Campo obrigatório!");
        ttUsu.setFont(new Font("Arial", 14));
        tfUsuario.setTooltip(ttUsu);
        
        Tooltip ttSal = new Tooltip("Salário do usuario. Campo obrigatório!");
        ttSal.setFont(new Font("Arial", 14));
        tfSalario.setTooltip(ttSal);
        
        Tooltip ttNascimento = new Tooltip("Nascimento do usuario. Campo obrigatório!");
        ttNascimento.setFont(new Font("Arial", 14));
        tfNascimento.setTooltip(ttNascimento);
        
    }

    @FXML
    private void clicarTabela(MouseEvent event) {
        setCamposFormulario();
    }

    @FXML
    private void pesquisarRegistro(KeyEvent event) {
        atualizarTabela();
    }

    
    
    
}
