package com.junqueira.dao;

import com.junqueira.model.Conta;
import com.junqueira.util.Alerta;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Session;

public class ContaDao {
    Alerta alerta = new Alerta();
    
    public void salvar(Conta conta){
        try{
            Session session = Conexao.getSessionFactory().openSession();
            session.beginTransaction();
            session.merge(conta);
            session.getTransaction().commit();
            session.close();
            alerta.msgInformacao("Registro gravado com sucesso");
        }catch(Exception erro){
            alerta.msgInformacao("Ocorreu o erro ao tentar salvar: " + erro);
        }
    }
    
    public void excluir(Conta conta){
        try{
            Session session = Conexao.getSessionFactory().openSession();
            session.beginTransaction();
            session.delete(conta);
            session.getTransaction().commit();
            session.close();
            System.out.println("Registro excluído com sucesso");
        }catch(Exception erro){
            System.out.println("Ocorreu o erro ao tentar excluir: " + erro);
        }
    }
    public List<Conta> consultar(String conta){
        List<Conta> lista = new ArrayList();
        Session session = Conexao.getSessionFactory().openSession();
        session.beginTransaction();
        
        if(conta.length() == 0){
            lista = session.createQuery(" from Conta ").getResultList();
        }else{
            lista = session.createQuery( "from Conta c where c.usuario like "+"'"+conta+"%'").getResultList();
        }
        
        session.getTransaction().commit();
        session.close();
        
        return lista;
    }
}
