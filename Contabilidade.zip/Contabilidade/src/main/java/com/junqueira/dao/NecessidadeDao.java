package com.junqueira.dao;

import com.junqueira.model.Conta;
import com.junqueira.model.Necessidade;
import com.junqueira.util.Alerta;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Session;

public class NecessidadeDao {
    Alerta alerta = new Alerta();
    
    public void salvar(Necessidade necessidade){
        try{
            Session session = Conexao.getSessionFactory().openSession();
            session.beginTransaction();
            session.merge(necessidade);
            session.getTransaction().commit();
            session.close();
            alerta.msgInformacao("Registro gravado com sucesso");
        }catch(Exception erro){
            alerta.msgInformacao("Ocorreu o erro ao tentar salvar: " + erro);
        }
    }
    
    public void excluir(Necessidade necessidade){
        try{
            Session session = Conexao.getSessionFactory().openSession();
            session.beginTransaction();
            session.delete(necessidade);
            session.getTransaction().commit();
            session.close();
            System.out.println("Registro excluído com sucesso");
        }catch(Exception erro){
            System.out.println("Ocorreu o erro ao tentar excluir: " + erro);
        }
    }
    public List<Necessidade> consultar(String necessidade){
        List<Necessidade> lista = new ArrayList();
        Session session = Conexao.getSessionFactory().openSession();
        session.beginTransaction();
        
        if(necessidade.length() == 0){
            lista = session.createQuery(" from Necessidade ").getResultList();
        }else{
            lista = session.createQuery( "from Necessidade n where n.usuario like "+"'"+necessidade+"%'").getResultList();
        }
        
        session.getTransaction().commit();
        session.close();
        
        return lista;
    }
}
