package com.junqueira.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "conta")
public class Conta implements Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;
    
    @OneToOne
    private Usuario usuario;
    
    @Column(name = "aluguel", length = 100, nullable = false)
    private Double aluguel;
    
    @Column(name = "agua", length = 100, nullable = false)
    private Double agua;
    
    @Column(name = "luz", length = 100, nullable = false)
    private Double luz;
    
    @Column(name = "netflix", length = 100, nullable = false)
    private Double netflix;
    
    @Column(name = "internet", length = 100, nullable = false)
    private Double internet;
    
    @Column(name = "data", length = 100, nullable = false)
    private String data;
    
    @Column(name = "total_conta", length = 100)
    private Double total_Conta;
    
    @Column(name = "divisao_conta", length = 100)
    private Double divisao_Conta;
    
    @Column(name = "divisao_netflix", length = 100)
    private Double divisao_netflix;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Double getAluguel() {
        return aluguel;
    }

    public void setAluguel(Double aluguel) {
        this.aluguel = aluguel;
    }

    public Double getAgua() {
        return agua;
    }

    public void setAgua(Double agua) {
        this.agua = agua;
    }

    public Double getLuz() {
        return luz;
    }

    public void setLuz(Double luz) {
        this.luz = luz;
    }

    public Double getNetflix() {
        return netflix;
    }

    public void setNetflix(Double netflix) {
        this.netflix = netflix;
    }

    public Double getInternet() {
        return internet;
    }

    public void setInternet(Double internet) {
        this.internet = internet;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public Double getTotal_Conta() {
        return total_Conta;
    }

    public void setTotal_Conta(Double total_Conta) {
        this.total_Conta = total_Conta;
    }

    public Double getDivisao_Conta() {
        return divisao_Conta;
    }

    public void setDivisao_Conta(Double divisao_Conta) {
        this.divisao_Conta = divisao_Conta;
    }

    public Double getDivisao_netflix() {
        return divisao_netflix;
    }

    public void setDivisao_netflix(Double divisao_netflix) {
        this.divisao_netflix = divisao_netflix;
    }

    
}
